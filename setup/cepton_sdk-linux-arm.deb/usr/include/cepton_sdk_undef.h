/** Undefine macros.
 */
#undef CEPTON_EXPORT
#undef CEPTON_DEPRECATED
