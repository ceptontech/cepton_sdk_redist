/** Undefine macros.
 */
#undef EXPORT
#undef DEPRECATED
