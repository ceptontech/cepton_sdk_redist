/** Undefine macros.
 */
#undef COMPILING
#undef EXPORT
#undef DEPRECATED
