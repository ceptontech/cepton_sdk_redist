/** Import macros.
 */
#ifdef _WIN32
#define EXPORT __declspec(dllimport)
#else
#define EXPORT
#endif